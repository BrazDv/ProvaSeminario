from django.contrib import admin
from .models import Turma

# Register your models here.

admin.site.register(Turma)
