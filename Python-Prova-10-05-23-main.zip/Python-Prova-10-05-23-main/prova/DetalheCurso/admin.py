from django.contrib import admin
from .models import DetalheCurso

# Register your models here.

admin.site.register(DetalheCurso)